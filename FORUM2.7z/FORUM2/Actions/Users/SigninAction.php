<?php
require('Database.php');
if(isset($_POST['Valider']))
{ //Cheking if varibles are not emty
    if( !empty($_POST['Signin_Pseudo']) AND !empty($_POST['Signin_pass']))
    {
        $Signin_pas = htmlspecialchars($_POST['Signin_pass']);
        $Signin_Pseudo = htmlspecialchars($_POST['Signin_Pseudo']);
        //Verification if User exist in the database !
        $userValidationTest= $DDB->prepare('SELECT*FROM USERS WHERE Pseudo = ?');
        $userValidationTest->execute(array($Signin_Pseudo));

        if($userValidationTest->rowCount() >0)
        {
            $UsersInfos = $userValidationTest->fetch();
            $Signin_pas_encriped = sha1($Signin_pas);
            if($Signin_pas_encriped === $UsersInfos['Pass'])
            {
              
                //Users authentification !
                $_SESSION['Auth']=true;
                $_SESSION['Pseudo']= $UsersInfos['Pseudo'];
                $_SESSION['Lastname']= $UsersInfos['Lastname'];
                $_SESSION['Firstname']= $UsersInfos['Firstname'];
                header('Location:../../Index.php');
            }else header('Location:../../Signin.php?Signin_eror=Wrong_password');
        }else header('Location:../../Signin.php?Signin_eror=Invalid_user');
    }else header('Location:../../Signin.php?Signin_eror=Empty');
}


?>