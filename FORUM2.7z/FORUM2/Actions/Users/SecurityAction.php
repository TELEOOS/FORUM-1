<?php
session_start();
if(!isset($_SESSION['Auth']))
{
    header('Location:../../Signin.php');
}
?>