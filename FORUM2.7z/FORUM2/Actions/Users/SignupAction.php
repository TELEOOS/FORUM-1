<?php
require('Database.php');
if(isset($_POST['Validate']))
{
    if(!empty($_POST['Pseudo'])  AND !empty($_POST['Lastname']) AND !empty($_POST['Firstname']) AND !empty($_POST['Pass']))
    {
        $User_pseudo = htmlspecialchars($_POST['Pseudo']);
        $User_Lastname = htmlspecialchars($_POST['Lastname']);
        $User_Firstname = htmlspecialchars($_POST['Firstname']);
        $User_Password = htmlspecialchars($_POST['Pass']);
        if(strlen($User_Firstname) <=50 AND strlen($User_pseudo) <=50 AND strlen($User_Lastname) <=50)
        {
            $ChekingIfUserExistIndatabase= $DDB->prepare("SELECT*FROM USERS WHERE Pseudo = ? AND Lastname = ?");
            $ChekingIfUserExistIndatabase->execute(array($User_pseudo,$User_Lastname));

            if($ChekingIfUserExistIndatabase->rowCount() == 0)
            {
                $User_Password_criped = sha1($User_Password);
                $InsertUserIndatabase = $DDB->prepare("INSERT INTO USERS(Pseudo,Lastname,Firstname,Pass) VALUES(?,?,?,?)");
                $InsertUserIndatabase->execute(array($User_pseudo,$User_Lastname,$User_Firstname,$User_Password_criped));
                $UsersInfos = $ChekingIfUserExistIndatabase->fetch();
                
                $_SESSION['Auth']=true;
                $_SESSION['Pseudo']= $UsersInfos['Pseudo'];
                $_SESSION['Lastname']= $UsersInfos['Lastname'];
                $_SESSION['Firstname']= $UsersInfos['Firstname'];

                header('Location:../../Index.php');

            }else header('Location:../../Signup.php?Signup_err=Already');
        }else header('Location:../../Signup.php?Signup_err=Long_string');
    } else header('Location:../../Signup.php?Signup_err=Empty');
}

?>