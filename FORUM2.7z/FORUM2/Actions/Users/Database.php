<?php
$Pilot = "mysql:host=127.0.0.1;dbname=FORUM2;charset=UTF8";
$User ="root";
$UserPass ="Brw1506#";

try{
    session_start();
    $DDB= new PDO($Pilot,$User,$UserPass);
    $DDB->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    // $creatingDatabase= $DDB->prepare('ALTER TABLE Quetions  CHANGE ID_author  Question_ID_Athor INT');
    // $creatingDatabase->execute();
}catch(PDOException $e){
    echo "Connection falled please try again !<br>" .$e->getMessage();
}


?>