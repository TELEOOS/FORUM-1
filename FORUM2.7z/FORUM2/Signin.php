<!DOCTYPE html>
<html lang="en">
<?php require("Includes/head.php"); ?>
<body>
<?php require("Includes/Navbar.php"); ?>
  <br><br>
    <form class="container" method="post" action="Actions/Users/SigninAction.php">
    <?php
    if(isset($_GET['Signin_eror']))
    {
      $Signin_eror = htmlspecialchars($_GET['Signin_eror']);
      switch($Signin_eror)
      {
        case "Empty":
          echo "<p>Please all fields must be filled !</p>";
        break;
        case "Invalid_user":
          echo "<p>Please this user doesn't  exist !</p>";
        break;
        case "Wrong_password":
          echo "<p>Please input a valid password !</p>";
        break;
      }
    }
    ?>
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Pseudo</label>
          <input type="text" class="form-control"name="Signin_Pseudo">
        </div>
          <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Password</label>
            <input type="password" class="form-control" name="Signin_pass">
          </div>
          <button type="submit"  name="Valider" class="btn btn-primary">Sign in</button><br><br>
        <p>Je n'ai pas de compte <a href="Signup.php">creer</a>un compte</p>
      </form>   
</body>
</html>