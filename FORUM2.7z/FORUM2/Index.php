<?php
require('Actions/Users/SecurityAction.php');
 ?>
<!DOCTYPE html>
<html lang="en">
<?php require('Includes/head.php'); ?>
<body>
<?php require('Includes/Navbar.php'); ?>
<h1>Hello Mr <?=$_SESSION['Lastname'];?> comment vas tus ?</h1>
</body>
</html>