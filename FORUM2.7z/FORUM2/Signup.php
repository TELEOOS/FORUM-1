<?php require('Actions/Users/SignupAction.php');  ?>
<!DOCTYPE html>
<html lang="en">
<?php require("Includes/head.php"); ?>
<body>
<?php require("Includes/Navbar.php"); ?>
<br><br>
    <form class="container" method="post" action="Actions/Users/SignupAction.php">
    <?php
    if(isset($_GET['Signup_err']))
    {
      $Signup_err = htmlspecialchars($_GET['Signup_err']);
      switch($Signup_err)
      {
        case "Empty":
          echo "<p>Please all fields must be filled !</p>";
        break;
        case "Long_string":
          echo "<p>Please the Pseudo ,lastname and firstname must not be more than 50 chars</p>";
        break;
        case "Already":
          echo "<p>Please this user already exist !</p>";
        break;
      }
    }
    
    ?>
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Pseudo</label>
          <input type="text" class="form-control" name="Pseudo">
        </div>
        <div class="mb-3">
          <label for="exampleInputPassword1" class="form-label">Lastname</label>
          <input type="text" class="form-control" name="Lastname">
        </div>
        <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Firstname</label>
            <input type="text" class="form-control" name="Firstname" >
          </div>
          <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Password</label>
            <input type="password" class="form-control" name="Pass">
          </div>
          <button type="submit" name="Validate" class="btn btn-primary">Sign up</button><br><br>
          <p>J'ai deja un  compte <a href="Signin.php">creer</a>un compte</p>
      </form>   
</body>
</html>