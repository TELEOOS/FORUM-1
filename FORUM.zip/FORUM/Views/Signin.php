<?php
require("../Actions/signinAction.php");
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../Assets/style.css">
        <title>Inscription</title>
    </head>
    <body>
        <form action="../Actions/SigninAction.php" method="POST">
       
        <h1>Sínscrire</h1>
                <div class="Infos">
                    <input type="text" name="Lastname" placeholder="Nom">
                    <input type="text" name="Firstname" placeholder="Prenom">
                </div>
                <div class="Email">
                        <input type="text" name="Email" placeholder="Email">
                        <input type="text" name="Email2" placeholder="Confirmer votre email">
                </div>
                <div class="Pass">
                        <input type="password" name="Pass" placeholder="Mot de passe">
                        <input type="password" name="Pass2" placeholder="Confirmer votre mot de passe"><br><br>
            <input type="submit" name="Valider"value="Valider">
                </div>
            <a href="Signup.php"><p>I already have an account </p></a>
    
        </form>
        <?php
            if(isset($_GET["Signin_err"]))
            {
                 $err = htmlspecialchars($_GET["Signin_err"]);

                    if($err == "Lenght")
                    {
                        echo "Please the lastname and Firstname must be less than 50 chars  ";
                    }
                    elseif($err=="Empty")
                    {
                        echo "Please all fields must be filled ! ";
                    }
                    elseif($err=="SamePass")
                    {
                        echo "Please the passwords must be the same ! ";
                    }
                    elseif($err=="SameEmail")
                    {
                        echo "Please the mails must be the same ! ";
                    }
                    elseif($err=="EmailValid")
                    {
                        echo "Please input the valid mails ! ";
                    }
                    elseif($err=="Already")
                    {
                        echo "Please this user already exist! ";
                    }
                    else
                    {
                        echo "Donne !";
                    }
            }
        ?>
    </body>
</html>