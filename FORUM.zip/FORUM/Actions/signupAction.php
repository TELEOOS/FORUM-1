<?php 
require('Database.php');
if(isset($_POST['Valider'])){
   if(!empty($_POST['Pseudo']) AND !empty($_POST['Lastname']) AND !empty($_POST['Firstname']) AND  !empty($_POST['Pass']) )
   { // User infos
       $User_Pseudo = htmlspecialchars(($_POST['Pseudo']));
       $User_Lastname = htmlspecialchars(($_POST['Lastname']));
       $User_Firstname = htmlspecialchars(($_POST['Firstname']));
       $User_Pass=sha1(($_POST['Firstname']));
       //trying if user exist
       $CheckIfUserAlreadyExist = $DDB->prepare('SELECT pseudo FROM users WHERE Pseudo = ?');
       $CheckIfUserAlreadyExist->execute(array($User_Pseudo));


       if($CheckIfUserAlreadyExist->rowCount() == 0)
       {//insrt user in the database 
            $InsertUser = $DDB->prepare('INSERT INTO users(Pseudo,Lastname,Firstname,Pass) VALUES(?,?,?,?)');
            $InsertUser->execute(array($User_Pseudo,$User_Lastname,$User_Firstname,$Pseudo_Pass));
            // User data recuperation 
            $getInfoOfThisUser =$DDB->prepare('SELECT ID, Pseudo,Lastname,Firstname FROM users WHERE Lastname = ? AND Firstname = ? AND Pseudo = ? ');
            $getInfoOfThisUser->execute(array($User_Lastname,$User_Firstname,$User_Pseudo));
            $user_infos = $getInfoOfThisUser->fetch(); // Keeping user infos recuperation by $getInfoOfThisUser in $user_infos
            //User authentification 
            $_SESSION['auth'] = true;
            $_SESSION['ID'] = $user_infos['ID'];
            $_SESSION['Lastname'] = $user_infos['Lastname'];
            $_SESSION['Firstname'] = $user_infos['Firstname'];
            $_SESSION['Pseudo'] = $user_infos['Pseudo'];
            header('Location:../Index.php');

       }
       else
       {
           $error = "This user alredy exist";
       }
   }
   else
   {
        $error = "Please all fields must be filled !";
   }
}
?>
