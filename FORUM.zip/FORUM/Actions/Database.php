<?php
session_start();
$pilot = "mysql:host=127.0.0.1;dbname=FORUM";
$User = "root";
$Pas ="";
try{
    $DDB= new PDO($pilot,$User,$Pas);
    $DDB->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e){
    echo "Connection falled ! please try again " .$e->getMessage();
}



?>