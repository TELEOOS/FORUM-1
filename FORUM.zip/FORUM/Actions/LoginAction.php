<?php
require('Actions/Database.php');
require('securityAction.php');
if(isset($_POST['Valider'])){
    if(!empty($_POST['Pseudo']) AND !empty($_POST['Lastname']) AND !empty($_POST['Firstname']) AND  !empty($_POST['Pass']) )
    { // User infos
        $User_Pseudo = htmlspecialchars(($_POST['Pseudo']));
        $User_Pass=htmlspecialchars(($_POST['Firstname']));
        //trying if user exist
        $CheckIfUserAlreadyExist = $DDB->prepare('SELECT * FROM users WHERE Pseudo = ?');
        $CheckIfUserAlreadyExist->execute(array($User_Pseudo));
 
 
        if($CheckIfUserAlreadyExist->rowCount() > 0)
        {
            $user_infos = $CheckIfUserAlreadyExist->fetch();
            if(password_verify($user_pass,$user_infos['Pass']))
            {
                $_SESSION['auth'] = true;
                $_SESSION['ID'] = $user_infos['ID'];
                $_SESSION['Lastname'] = $user_infos['Lastname'];
                $_SESSION['Firstname'] = $user_infos['Firstname'];
                $_SESSION['Pseudo'] = $user_infos['Pseudo'];
                header('Location:../Index.php');
            }
            else
            {
                $error = "Please this password isn't correct !";
            }
        }
        else
        {
            $error = "This user doesn't exist";
        }
    }
    else
    {
         $error = "Please all fields must be filled !";
    }
 }



?>