<?php
require('../Config/Database.php');
if(isset($_POST['Valider'])){
    if(isset($_POST['Lastname']) AND isset($_POST['Firstname']) AND isset($_POST['Email']) AND isset($_POST['Email2']) AND isset($_POST['Pass']) AND isset($_POST['Pass2']))
    {//Trying if the fields aren't empty !
        if(!empty($_POST['Lastname']) AND !empty($_POST['Firstname']) AND !empty($_POST['Email']) AND !empty($_POST['Email2']) AND !empty($_POST['Pass']) AND !empty($_POST['Pass2']))
        { // Creating vars
            $Lastname = htmlspecialchars($_POST['Lastname']);
            $Firstname = htmlspecialchars($_POST['Firstname']);
            $Email = htmlspecialchars($_POST['Email']);
            $Email2 = htmlspecialchars($_POST['Email2']);
            $Pass = htmlspecialchars(sha1($_POST['Pass']));
            $Pass2 = htmlspecialchars(sha1($_POST['Pass2']));
            //Trying if  Lastname and Firsname don't have more than 50 chars
            if(strlen($Lastname) <= 50 AND strlen($FirstnameLenght) <= 50)
            {//Trying if the pass is valid
                if(filter_var($Email,FILTER_VALIDATE_EMAIL))
                {//Trying if the pass are the same 
                   if($Email == $Email2)
                   {
                        if($Pass === $Pass2)
                        {
                            //trying if user isn't in the database 
                            $Userverifying= $DDB->prepare("SELECT Lastname Firstname FROM USERS WHERE Lastname = ? AND Firstname = ? ");
                            $Userverifying->execute(array($Lastname,$Firstname));
                            $Data =$Userverifying->rowCount();
                         
                            if($Data == 0) 
                            {   // Insertion of user if it isn't in the database !
                                $inserttionOfUser = $DDB->prepare('INSERT INTO USERS(Lastname,Firstname,Email,Pass) VALUES(?,?,?,?)');
                                $inserttionOfUser->execute(array($Lastname,$Firstname,$Email,$Pass));
                                //GetingUserInfos
                                $GetinUsernfos = $DDB->prepare("SELECT ID,Lastname,Firstname ,Email FROM USERS WHERE  Lastname = ? AND Firstname = ? ");
                                $GetinUsernfos->execute(array($Lastname,$Firstname));
                                $UserInfos = $GetinUsernfos->fetch();
                                //User Authentification !
                                $_SESSION['Lastname'] = $UserInfos['Lastname'];
                                $_SESSION['Firstname'] = $UserInfos['Firstname'];
                                $_SESSION['Email'] = $UserInfos['Email'];
                                $_SESSION['ID'] = $UserInfos['ID'] ;
                                header("Location:../Home.php");
                            }else header("Location:../Views/signin.php?Singin_err=Already");
                        }else header("Location:../Views/signin.php?Singin_err=SamePass");
                   }else header("Location:../Views/signin.php?Singin_err=SameEmail");
                }else header("Location:../Views/signin.php?Singin_err=EmailValid");
            }else header('Location:../Views/signin.php?Singin_err=Lenght');
        }else header("Location:../Views/signin.php?Singin_err=Empty");
    }
}

?>