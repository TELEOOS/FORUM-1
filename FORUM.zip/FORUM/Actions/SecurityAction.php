<?php
session_start();
if(!isset($_SESSION['Lastname'])){
    header("Location:Views/Signup.php");
}
?>