<?php
require('../Config/Database.php');
if(isset($_POST['Valider']))
{
    if( !empty($_POST['Email'])  AND !empty($_POST['Pass']))
    {
        $Email = htmlspecialchars($_POST['Email']);
        $Pass = htmlspecialchars($_POST['Pass']);

        $UserVerifying = $DDB->prepare("SELECT *FROM USERS WHERE Email = ? AND Pass = ?");
        $UserVerifying ->execute(array($Pass,$Email));

        $UserIfos = $UserVerifying->fetch();
        $table = $UserVerifying->rowCount();

        if($table == 1)
        {
            if(filter_var($Email, FILTER_VALIDATE_EMAIL))
            {
                $Password = sha1($pass);
                if($Password == $UserIfos['Pass'])
                {
                    $_SESSION['Ath'] = true;
                    $_SESSION['Lastname'] = $UserIfos['Lastname'];
                    header('Location:../Home.php');
                }else header('Location:../Views/Signup.php?Connection_err=Wrong_pass');
            }else header('Location:../Views/Signup.php?Connection_err=Invalid_email');
        }else header('Location:../Views/Signup.php?Connection_err=Invalid_user');
    }else header('Location:../Views/Signup.php?Connection_err=Empty');
 
  
}


?>