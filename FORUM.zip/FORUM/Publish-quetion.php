<?php require('Actions/securityAction.php')?>
<!DOCTYPE html>
<html lang="en">
<?php require('Include/heade.php ');?>
<body>
<?php include('Include/navbar.php'); ?>

        
 
</body>
</html>