<?php
require('Actions/SecurityAction.php');
echo "Bonjour monsieur " .$_SESSION['Firstname']. "  " .$_SESSION['Lastname'] ."  Comment vas tu ?";
?>