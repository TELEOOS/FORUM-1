<?php require('Include/head.php');?>
<?php require('Actions/signupAction.php');?>
<!DOCTYPE html>
<html lang="en">
<body>
<br><br>
<form action="Actions/signupAction.php" class="container" method="POST">
<?php if(isset($error)){ echo $error;}?>
    <h1>Incrivez vous !</h1>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label" >Pseudo</label>
        <input type="text" class="form-control" name="Pseudo" placeholder="Pseudo">
    </div>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label" >Lastname</label>
        <input type="text" class="form-control" name="Lastname"  placeholder="Lastname" >
    </div>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label" >Firstname</label>
        <input type="text" class="form-control" name="Firstname"  placeholder="Firstname" >
    </div>
    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label" >Password</label>
        <input type="password" class="form-control" name="Pass" placeholder="Password">
    </div>
   
    <button type="submit" class="btn btn-primary" name="Valider">Valider</button><br>
    <a href="Login.php"><p>I've an an account</p> </a>
    </form>
</body>
</html>