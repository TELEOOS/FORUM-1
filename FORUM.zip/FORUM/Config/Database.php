<?php
$Pilot = "mysql:host=127.0.0.1;dbname=FORUM";
$User = "root";
$Pass = "Brw1506#";

try{
session_start();
    $DDB= new PDO($Pilot,$User,$Pass);
    $DDB->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    // $Table =$DDB->prepare("CREATE TABLE USERS(
    //     ID INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    //     Lastname VARCHAR(50),
    //     Firstname VARCHAR(50),
    //     Email VARCHAR(70),
    //     Pass VARCHAR(18)
    // )");
   // $Table->execute();
}catch(PDOException $e){
    echo "Connection falled please try again ! <br>" .$e->getMessage();
}



?>