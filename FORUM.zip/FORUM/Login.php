<?php
require('Actions/LoginAction.php');
?>
<!DOCTYPE html>
<html lang="en">
<?php require('Include/head.php');?>
<body>
<form action="Actions/signupAction.php" class="container" method="POST">
<?php if(isset($error)){ echo $error;}?>
    <h1>Connecter vous !</h1>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label" >Pseudo</label>
        <input type="text" class="form-control" name="Pseudo" placeholder="Pseudo">
    </div>
    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label" >Password</label>
        <input type="password" class="form-control" name="Pass" placeholder="Password">
    </div>
   
    <button type="submit" class="btn btn-primary" name="Valider">Login</button><br>
    <a href="signup.php"><p>I haven't an account</p> </a>
    </form>
</body>
</body>
</html>